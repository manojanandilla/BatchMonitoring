INSERT INTO users (name, email, framework) VALUES ('test', 'test@gmail.com', 'test, GWT');
INSERT INTO users (name, email, framework) VALUES ('test2', 'test@yahoo.com', 'Spring MVC, PLAY');
INSERT INTO users (name, email, framework) VALUES ('test3', 'test3@gmail.com', 'Spring MVC, JSF 2');